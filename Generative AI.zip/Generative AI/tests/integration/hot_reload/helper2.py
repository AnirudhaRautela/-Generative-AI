def get_doc_value():
    return 'MyExecutorAfterReload'
