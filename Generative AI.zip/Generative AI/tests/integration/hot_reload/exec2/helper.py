def get_doc_value():
    return 'MyExecutorBeforeReload'
