def helper_function():
    pass
