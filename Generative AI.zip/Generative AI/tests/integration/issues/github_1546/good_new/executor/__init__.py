from .my_crafter import GoodCrafterNew
