from jina import Executor
import sklearn
import tiny


class InstallReqsExecutor(Executor):
    pass
