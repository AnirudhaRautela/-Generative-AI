from jina import Executor


class TestExecutor(Executor):
    pass
