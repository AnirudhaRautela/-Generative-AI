import os
import sys
from os.path import dirname

file_dir = os.path.dirname(__file__)
sys.path.append(dirname(file_dir))
