from jina import Executor


class Exec(Executor):
    pass
