```{include} ../install.md
```

```{toctree}
:hidden:

docker
apple-silicon-m1-m2
windows
troubleshooting
```