:octicon:`terminal` Command-Line Interface
==========================================

.. argparse::
   :noepilog:
   :nodescription:
   :ref: jina.parsers.get_main_parser
   :prog: jina