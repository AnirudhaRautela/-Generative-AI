To update `jina` Protobuf:

```bash
docker run -v $(pwd)/jina/:/jina/ jinaai/protogen
```

````
```{include} docs.md
```
