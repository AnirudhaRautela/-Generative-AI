schema_all_executors = {
    'Jina::Executors::All': {
        'type': 'array',
        'minItems': 1,
    }
}
