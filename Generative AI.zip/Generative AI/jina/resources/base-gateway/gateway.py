from jina.serve.runtimes.gateway.gateway import BaseGateway

class PlaceHolderGateway(BaseGateway):
    pass