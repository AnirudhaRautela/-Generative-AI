if __name__ == '__main__':
    from jina_cli import main

    main()
