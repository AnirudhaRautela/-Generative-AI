from jina.logging.logger import JinaLogger

default_logger = JinaLogger('JINA')  #: a logger at the global-level
