"""
The :mod:`jina.proto` defines the protobuf used in jina. It is the core message protocol used in communicating between :class:`jina.orchestrate.deployments.Deployment`. It also defines the interface of a gRPC service.

"""
