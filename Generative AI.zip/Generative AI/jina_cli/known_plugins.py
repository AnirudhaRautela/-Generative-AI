plugin_info = {
    'now': {  # your sub-command
        'display-name': 'Jina Now',  # the name of your plugin/project
        'pip-package': 'jina-now',  # the pip package to install
    }
}
